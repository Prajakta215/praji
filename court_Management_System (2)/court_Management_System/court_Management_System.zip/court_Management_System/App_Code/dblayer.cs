using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
/// <summary>
/// Summary description for dblayer
/// </summary>
public class dblayer
{
    SqlConnection con = new SqlConnection();
    SqlCommand cmd;
    DataSet ds = new DataSet();
    SqlDataAdapter da;
    SqlDataReader dr;
	public dblayer()
	{
		//
		// TODO: Add constructor logic here
		//
	}
    public SqlDataReader select(string query)
    {
        try
        {

            con.ConnectionString = ("Data Source=.\\SQLEXPRESS;database=court;Integrated Security=True");
            con.Open();
            cmd = new SqlCommand(query, con);
            dr = cmd.ExecuteReader();
        }
        catch (Exception f)
        {
            dr = null;
        }
        return dr;
    }
    public int insertupdate(string query)
    {
        int i = 0;
        try
        {
            con.ConnectionString = ("Data Source=.\\SQLEXPRESS;database=court;Integrated Security=True");
            con.Open();
            cmd = new SqlCommand(query, con);
            i = cmd.ExecuteNonQuery();
        }
        catch (Exception t)
        {
            i = -1;
        }
        finally
        {
            con.Close();
            con.Dispose();
            cmd.Dispose();
        }
        return i;
    }
    public void conn()
    {
        con.Close();
        con.Dispose();
    }
    public DataSet dataadapter(string query)
    {
        try
        {

            con.ConnectionString = ("Data Source=.\\SQLEXPRESS;database=court;Integrated Security=True");
            ds.Clear();
            da = new SqlDataAdapter(query, con);
            da.Fill(ds);

        }
        catch (Exception f)
        {
            ds = null;
        }
        finally
        {
            con.Close();
            da.Dispose();
            con.Dispose();

        }
        return ds;
    }
}
