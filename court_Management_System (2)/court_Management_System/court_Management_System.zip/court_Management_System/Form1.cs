﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace court_Management_System
{
    public partial class Form1 : Form
    {
        dblayer db = new dblayer();
        SqlDataReader dr;

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                dr = db.select("select * from register where username='" + textBox1.Text + "' and password='" + textBox2.Text + "'");
                if (dr.Read())
                {

                    viewcase f = new viewcase();
                    f.Show();
               
                }
                else
                {
                    MessageBox.Show("invalid password");
                }
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.ToString());
            }
            
           

        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (textBox3.Text == "admin" && textBox4.Text == "admin")
            {

                main f = new main();
                f.Show();
            }
            else
            {
                MessageBox.Show("invalid password");
            }
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            register re = new register();
            re.Show();
        }
    }
}
