﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace court_Management_System
{
    public partial class addcase : Form
    {
        string connString = "Data Source=.\\SQLEXPRESS;Initial Catalog=court;Integrated Security=True";
        dblayer db = new dblayer();
        SqlDataReader dr;
        public addcase()
        {
            InitializeComponent();
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                //     string connString = @"Data Source=ASHWINI-LAPY\SQLEXPRESS;Initial Catalog=complete;Integrated Security=True;Pooling=False";
                //SqlDataReader reader = null;

                SqlConnection conn = null;

                conn = new SqlConnection(connString);
                conn.Open();


                SqlCommand cmd = new SqlCommand("select * from register where case_id='" + comboBox2.SelectedItem.ToString() +"'", conn);
                // cmd.Parameters.AddWithValue("@Barcode", textBox1.Text);
                dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    textBox3.Text = dr[2].ToString();
                    textBox5.Text = dr[0].ToString();
                    textBox4.Text = dr[3].ToString();
                   comboBox1 .Text  = dr[6].ToString();
                    textBox6.Text = dr[5].ToString();
                   // textBox7.Text = dr[0].ToString();

                }
                else
                {

                        MessageBox.Show("already added");
                    }



                }
            catch (Exception ee)
            {
                MessageBox.Show(ee.ToString());
            }

        }

        private void addcase_Load(object sender, EventArgs e)
        {
            dr = db.select("select distinct case_id from register");
            while (dr.Read())
            {
                comboBox2.Items.Add(dr[0].ToString());
               
            }
            db.conn();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int i = db.insertupdate("insert into addcase values('" + comboBox2 .SelectedItem .ToString () + "','" + textBox3.Text + "','" + textBox5.Text + "','" + textBox4.Text + "','" + textBox6.Text + "','" + comboBox1 .SelectedItem .ToString () + "','" + textBox7 .Text  + "','" + textBox1.Text + "','" + textBox8.Text + "')");
            if (i >= 1)
            {
                MessageBox.Show("case details updated");
            }
            else
            {
                MessageBox.Show("already added");
            }
        }
    }
}
