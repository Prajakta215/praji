﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace court_Management_System
{
    public partial class viewcase : Form
    {
        dblayer db = new dblayer();
        SqlDataReader dr;
        string connString = "Data Source=.\\SQLEXPRESS;Initial Catalog=court;Integrated Security=True";
        public viewcase()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string str = "select * from addcase where case_id='" + textBox1 .Text  + "'";
                SqlDataAdapter DAap = new SqlDataAdapter(str, connString);
                DataSet DS = new DataSet();
                DAap.Fill(DS, "labdetails");
                DataTable DT = DS.Tables[0];
                dataGridView1.DataSource = DT;
                // dataGridView1 
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString(), "...       ", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }
    }
}
